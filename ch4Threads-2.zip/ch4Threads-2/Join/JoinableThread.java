package ch4Threads.Join;

class JoinableThread extends Thread {
  public void run() {
    System.out.println("Worker working");
  }
}