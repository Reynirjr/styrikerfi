Start no thread/singlethreaded enumeration of the fibonacci number up to 46 using:
java -cp /home/helmut/workspace/OperatingSystems/bin/ ch4Threads.ParallelFibonacci.FibonacciSinglethreaded 46

Start multithreaded enumeration of the fibonacci number up to 46 (4 threads in parallel):
java -cp /home/helmut/workspace/OperatingSystems/bin/ ch4Threads.ParallelFibonacci.FibonacciMultithreaded 4 46
